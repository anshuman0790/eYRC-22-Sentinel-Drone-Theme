import cv2
import numpy as np
img = cv2.imread('yellow_detect.jpeg')
#cv2.imshow(' ',img)
#cv2.waitKey(0)

blurred = cv2.GaussianBlur(img, (13,13), 0)

img_HSV = cv2.cvtColor(blurred,cv2.COLOR_BGR2HSV)
#cv2.imshow(' ',img_HSV)
#cv2.waitKey(0)

lowest = np.array([22, 93, 0])
highest = np.array([45, 255, 255])

hiding = cv2.inRange(img_HSV, lowest, highest)
result=cv2.bitwise_and(img,img,mask=hiding)
#cv2.imshow(' ',result)
#cv2.waitKey(0)
result1 = cv2.cvtColor(result, cv2.COLOR_BGR2GRAY)
contours,hierarchy=cv2.findContours(result1,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
#cv2.drawContours(img,contours,-1,(0,255,0),2)
#cv2.imshow(' ',img)
#cv2.waitKey(0)

for i in contours:
    M=cv2.moments(i)
    if M['m00']!=0:
        cX=int(M["m10"]/M["m00"])
        cY=int(M["m01"]/M["m00"])
        print(cX,cY)